package repl

import (
	`syscall`
)

const ioctlCode = syscall.TCGETS
